# 128-bit AES

### Structure of AES (for encryption):

* Initial Round
    * AddRoundKey
* Round 1 to 9
    * SubBytes
    * ShiftRows
    * MixColumns
    * AddRoundKey
* Cipher Text (Last Round)
    * SubBytes
    * ShiftRows
    * AddRoundKey

## Synopsis
Encryption and decryption programs written in C++ to improve my understanding of the 128-bit AES cipher.

## File Details
- plainterx_file - 原始檔案. 
- key_file - 解密檔案
- sbox_file-加密使用16進位宣告檔案
- inv_sbox_file-解密使用16進位宣告檔案
- aes.h - 呼叫encrypt和decrypt函數.
- aes.c - encrypt和decrypt function撰寫
- main.c-主要執行檔案

####自動產生main執行檔
## Makefile
To run the simply do **make**

####手動產生main執行檔

## Compilation
If using the g++ compiler you can do:
**gcc main.c aes.c -o main**

## Usage
To run the main執行檔 simply do **./main key_file plaintext_file sbox_file inv_sbox_file** after compilation.   ）


