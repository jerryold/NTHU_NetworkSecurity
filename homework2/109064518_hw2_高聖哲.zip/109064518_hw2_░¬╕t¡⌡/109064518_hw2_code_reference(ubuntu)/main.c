#include "aes.h"
#define RED_BOLD "\x1b[;31;1m"

#define BLU_BOLD "\x1b[;34;1m"

#define YEL_BOLD "\x1b[;33;1m"

#define GRN_BOLD "\x1b[;32;1m"

#define CYAN_BOLD_ITALIC "\x1b[;36;1;3m"

#define RESET "\x1b[0;m"

int main(int argc, char *argv[])
{
    if(argc < 5) {
        printf("ERROR: expecting 4 paths \"key_file, plaintext_file, sbox_file, inv_sbox_file\"\n");
        exit(-1);
    }

    char* key_file = NULL, *state_file = NULL, *sbox_file = NULL, *inv_sbox_file = NULL;
    key_file = argv[1];
    state_file = argv[2];
    sbox_file = argv[3];
    inv_sbox_file = argv[4];

    printf(YEL_BOLD"[109064518 Sheng-Che Kao Assignment#2]\n" RESET);
	printf(YEL_BOLD"=============================\n" RESET);
	printf(YEL_BOLD " 128-bit AES Decryption Tool\n " RESET);
	printf(YEL_BOLD "=============================\n" RESET);
    initialize(key_file, state_file, sbox_file, inv_sbox_file);
    encrypt();
    decrypt();
    assertStateIsOrigMesg();

    printf("\nProgram ended Successfully\n");
    return 0;
}